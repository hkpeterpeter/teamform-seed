var app = angular.module('miniQuiz', []);

app.directive('test', function(quizFactory) {
	return {
		restrict: 'AE',
		scope: {},
		templateUrl: 'entrytemplate.html',
		link: function(scope, elem, attrs) {
			scope.start = function() {
				scope.id = 0;
				scope.quizOver = false;
				scope.inProgress = true;
				scope.getQuestion();
			};

			scope.reset = function() {
				scope.inProgress = false;
				scope.score = 0;
			}

			scope.getQuestion = function() {
				var q = quizFactory.getQuestion(scope.id);
				if(q) {
					scope.question = q.question;
					scope.options = q.options;
					scope.answer = q.answer;
					scope.answerMode = true;
				} else {
					scope.quizOver = true;
				}
			};


			scope.checkAnswer = function() {
				if(!$('input[name=answer]:checked').length) return;

				var ans = $('input[name=answer]:checked').val();

				if(ans == scope.options[scope.answer]) {
					scope.score++;
					scope.correctAns = true;
				} else {
					scope.correctAns = false;
				}

				scope.answerMode = false;
			};

scope.check = function() {
				console.log("haha");
			};

			scope.nextQuestion = function() {
				if(!$('input[name=answer]:checked').length) return;

				var ans = $('input[name=answer]:checked').val();

				if(ans == scope.options[scope.answer]) {
					scope.score++;
					scope.correctAns = true;
				} else {
					scope.correctAns = false;
				}
				scope.id++;
				scope.getQuestion();
			}

			scope.reset();
		}
	}
});

app.factory('quizFactory', function() {
	var questions = [
		{
			question: "In C Programming, which of the following cannot be checked in a switch case statement ?",
			options: ["Integer", "Enum", "Character", "Float"],
			answer: 3
		},
		{
			question: "In C Programming ________ are called tokens.",
			options: ["Characters", "All of the above", "Punctuation", "Individual Words"],
			answer: 1
		},
		{
			question: "In MVC model, M stands for _________.",
			options: ["Monitor", "Model", "Minimal", "Multiple"],
			answer: 1
		},
		{
			question: "In C Programming, which type of variable would be declared by the syntax - String str;   ? ",
			options: ["Compilation Error", "String", "Character", "Text"],
			answer: 0
		},
		{	
			question: "In C Programming, type of value stored inside variable can be identified using ________ of the variable.",
			options: ["Variable Size", "Data Type", "Variable Name", "None of these"],
			answer: 1
		},
		{	
			question: "In Java programming, which of the following would compile without error?",
			options: ["int a = Math.abs(-5);", "int b = Math.abs(5.0);", "int c = Math.abs(5.5F);", "int d = Math.abs(5L);"],
			answer: 0
		},
		{	
			question: "Which of the following attacks could not be avoided by any security control?",
			options: ["XSS", "SQL Injection", "CSRF", "Zero Day Attack"],
			answer: 3
		},
		{	
			question: "Which of the following methods is used to preserve Confidentiality?",
			options: ["Hashing", "Encryption", "Compression", "Access Control"],
			answer: 1
		},
		{	
			question: "Which of the following port number is used for NetBIOs? ",
			options: ["TCP 53", "UDP 137", "UDP 123", "TCP 67"],
			answer: 1
		},
		{	
			question: "Which of the following network devices could seperate broadcast domain?",
			options: ["Hub", "Switch", "Bridge", "Router"],
			answer: 3
		},
		{	
			question: "Which of the following IP address is a private IP address?",
			options: ["172.16.33.6", "172.33.255.234", "172.255.255.222", "224.52.33.6" ],
			answer: 0
		},
		{	
			question: "In Bash Shell, The command ‘compgen -c’ shows",
			options: ["all variable names", "all system wide aliases", "full list of all commands", "none of these"],
			answer: 2
		}

	];

	return {
		getQuestion: function(id) {
			if(id < questions.length) {
				return questions[id];
			} else {
				return false;
			}
		}
	};
});

// Controller
$scope.isLast = function(check) {
    var cssClass = check ? 'last' : null;
    return cssClass;
};